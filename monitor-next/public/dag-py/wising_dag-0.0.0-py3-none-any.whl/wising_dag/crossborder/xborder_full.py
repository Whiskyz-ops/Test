"""The full cross-border graph: india_full + us_full + ftc merged into one
registry, with every one of ftc.py's ten `*_BoundaryFtc` leaves redefined
to in-graph values. Port of prototypes/graph-pilot/xborder-full-nodes.js.

After this module, the product's headline number — net unrelieved double
tax across both directions — is computed end-to-end from raw Layer 1 form
data: India income → India tax (individual OR entity, routed) → US income
→ US federal tax → residency (worldwide flags, derived not read) → FTC
both directions → netUnrelievedDoubleTaxUsd.

`usEntityKind`/`baseYearUs` are NOT closed here (both still read
`ctx["model"]`, unreachable in the real `{router, india, us}` ctx shape) —
closed instead in `us/ustax_full.py`, composed after this module (it also
needs `entityResult`/`metaResult`, which only exist once `core/
orchestration.py` has run). See that file's own header for the real
closure.
"""
from __future__ import annotations

from ..core.fx_util import fx_rate
from ..core.graph import NodeDef
from ..core.registry import NodeRegistry
from ..core.util import num, safe
from ..india import india_full
from ..india.aggregate_india_income import india_income_basket_split
from ..us import us_full
from . import ftc

OVERRIDE_REASON = "xborder-full-nodes.js wiring: redefined FTC boundaries to in-graph values"


def build(base: NodeRegistry) -> NodeRegistry:
    r = base.extend()
    r = india_full.build(r)
    r = us_full.build(r)
    r = ftc.build(r)

    # ---- scope leaves (mirror normalize()'s scopeHasUs) ---------------------
    r.register("routerJurisdictionXB", NodeDef(deps=(), compute=lambda d, ctx: safe(ctx.get("router"), "jurisdiction", None), layer1_fields=("router.jurisdiction",)))
    r.register("routerUsSignalXB", NodeDef(
        deps=(),
        compute=lambda d, ctx: (
            num(safe(ctx.get("router"), "us_days", 0)) > 0 or safe(ctx.get("router"), "is_us_citizen", False) is True or
            safe(ctx.get("router"), "has_green_card", False) is True or safe(ctx.get("router"), "has_us_source_income_or_assets", False) is True
        ),
        layer1_fields=("router.us_days", "router.is_us_citizen", "router.has_green_card", "router.has_us_source_income_or_assets"),
    ))

    r.override("hasUsScopeBoundaryFtc", NodeDef(
        deps=("routerJurisdictionXB", "routerUsSignalXB"),
        compute=lambda d, ctx: (
            False if d["routerJurisdictionXB"] in ("single_india", "india_only") else
            True if d["routerJurisdictionXB"] in ("single_us", "us_only") else d["routerUsSignalXB"]
        ),
    ), reason=OVERRIDE_REASON)
    # .get(), not [...] — entity/NRA usTaxResult branches (us/ustax_full.py)
    # carry no feieAppliedUsd field at all (§911 FEIE only applies on the
    # individual path); JS's bare `d.usTaxResult.feieAppliedUsd` reads
    # undefined there, not a crash.
    r.override("feieExcludedUsdBoundaryFtc", NodeDef(deps=("usTaxResult",), compute=lambda d, ctx: d["usTaxResult"].get("feieAppliedUsd") or 0), reason=OVERRIDE_REASON)
    r.override("usIsNraBoundaryFtc", NodeDef(
        deps=("usEntityKind", "files1040nr", "s6013hElection"),
        compute=lambda d, ctx: d["usEntityKind"] not in ("ccorp", "scorp", "partnership", "trust") and d["files1040nr"] and not d["s6013hElection"],
    ), reason=OVERRIDE_REASON)
    r.override("indiaIncomeTotalUsdBoundaryFtc", NodeDef(deps=("totalIndiaIncomeInr",), compute=lambda d, ctx: d["totalIndiaIncomeInr"] / fx_rate(ctx)), reason=OVERRIDE_REASON)
    r.override("usTaxableIncomeUsdBoundaryFtc", NodeDef(deps=("usTaxResult",), compute=lambda d, ctx: d["usTaxResult"]["taxableIncomeUsd"]), reason=OVERRIDE_REASON)
    r.override("usIncomeTaxUsdBoundaryFtc", NodeDef(deps=("usTaxResult",), compute=lambda d, ctx: d["usTaxResult"]["incomeTaxUsd"]), reason=OVERRIDE_REASON)
    r.override("usTotalIncomeUsdBoundaryFtc", NodeDef(deps=("usTaxResult",), compute=lambda d, ctx: d["usTaxResult"]["totalIncomeUsd"]), reason=OVERRIDE_REASON)
    r.override("usSourceIncomeUsdBoundaryFtc", NodeDef(deps=("usTaxResult",), compute=lambda d, ctx: d["usTaxResult"]["usSourceIncomeUsd"]), reason=OVERRIDE_REASON)
    r.override("indiaTotalTaxUsdBoundaryFtc", NodeDef(deps=("totalTaxInrCombined",), compute=lambda d, ctx: d["totalTaxInrCombined"] / fx_rate(ctx)), reason=OVERRIDE_REASON)
    r.override("indiaTotalIncomeUsdBoundaryFtc", NodeDef(
        deps=("isEntityTaxpayer", "totalIncomeInrV3", "entityTaxableInrBoundary"),
        compute=lambda d, ctx: (d["entityTaxableInrBoundary"] if d["isEntityTaxpayer"] else d["totalIncomeInrV3"]) / fx_rate(ctx),
    ), reason=OVERRIDE_REASON)
    r.override("indiaWorldwideBoundaryFtc", NodeDef(deps=("residencyResult",), compute=lambda d, ctx: bool(d["residencyResult"]["india"]["worldwide"])), reason=OVERRIDE_REASON)
    # Reads usTaxResult.worldwide, not residencyResult.us.worldwide (see
    # ftc.py's own comment on this boundary) — usTaxResult is already the
    # routed, entity/NRA-aware result, so this stays correct for every
    # taxpayer shape without re-deriving entity/NRA routing a second time.
    r.override("usWorldwideBoundaryFtc", NodeDef(deps=("usTaxResult",), compute=lambda d, ctx: bool(d["usTaxResult"].get("worldwide"))), reason=OVERRIDE_REASON)
    r.override("usSourceTotalUsdBoundaryFtc", NodeDef(deps=("usTaxResult",), compute=lambda d, ctx: d["usTaxResult"]["usSourceIncomeUsd"]), reason=OVERRIDE_REASON)

    # §904 basket split (task #46) — in-graph version of ftc.py's own
    # boundary, reading indiaIncomeModelResult (already in this composition
    # via india_full.build above) directly instead of ctx["model"]["income"]["india"].
    r.override("indiaPassiveIncomeUsdBoundaryFtc", NodeDef(deps=("indiaIncomeModelResult",), compute=lambda d, ctx: india_income_basket_split(d["indiaIncomeModelResult"])["passiveInr"] / fx_rate(ctx)), reason=OVERRIDE_REASON)
    r.override("indiaGeneralIncomeUsdBoundaryFtc", NodeDef(deps=("indiaIncomeModelResult",), compute=lambda d, ctx: india_income_basket_split(d["indiaIncomeModelResult"])["generalInr"] / fx_rate(ctx)), reason=OVERRIDE_REASON)
    r.override("usPassiveIncomeUsdBoundaryFtc", NodeDef(
        deps=("aggregateUsIncomeResult",),
        compute=lambda d, ctx: (
            d["aggregateUsIncomeResult"]["interestUs"]["usd"] + d["aggregateUsIncomeResult"]["ordinaryDividendsUs"]["usd"] +
            d["aggregateUsIncomeResult"]["ltcgUs"]["usd"] + d["aggregateUsIncomeResult"]["stcgUs"]["usd"] + d["aggregateUsIncomeResult"]["rentalUs"]["usd"]
        ),
    ), reason=OVERRIDE_REASON)
    r.override("usGeneralIncomeUsdBoundaryFtc", NodeDef(
        deps=("aggregateUsIncomeResult",),
        compute=lambda d, ctx: (
            d["aggregateUsIncomeResult"]["wages"]["usd"] + d["aggregateUsIncomeResult"]["businessUs"]["usd"] +
            d["aggregateUsIncomeResult"]["usRetirementIncome"]["usd"] + d["aggregateUsIncomeResult"]["otherOrdinaryIncomeUs"]["usd"]
        ),
    ), reason=OVERRIDE_REASON)
    r.override("foreignWagesTaxPaidUsdBoundaryFtc", NodeDef(deps=("aggregateUsIncomeResult",), compute=lambda d, ctx: d["aggregateUsIncomeResult"].get("foreignWagesTaxPaidUsd") or 0), reason=OVERRIDE_REASON)
    r.override("usIncomeInIndiaUsdBoundaryFtc", NodeDef(deps=("usIncomeForIndiaInr",), compute=lambda d, ctx: (
        d["usIncomeForIndiaInr"]["salaryInr"] + d["usIncomeForIndiaInr"]["businessInr"] + d["usIncomeForIndiaInr"]["housePropertyInr"] +
        d["usIncomeForIndiaInr"]["otherNormalInr"] + d["usIncomeForIndiaInr"]["stcgSlabInr"] + d["usIncomeForIndiaInr"]["ltcg197Inr"]) / fx_rate(ctx)), reason=OVERRIDE_REASON)
    r.override("indiaSalaryOutsideIndiaUsdBoundaryFtc", NodeDef(deps=("indiaIncomeModelResult",), compute=lambda d, ctx: (d["indiaIncomeModelResult"].get("salaryOutsideIndiaInr") or 0) / fx_rate(ctx)), reason=OVERRIDE_REASON)

    # Companion to hasUsScopeBoundaryFtc above — port of findings-nodes.js's
    # hasIndiaScopeXbr, added here (not in crossborder/findings.py) because
    # it's shared scope infrastructure consumed by findings across all three
    # domains (e.g. india/findings.py's lrs_limit), not a crossborder-only
    # concept itself.
    r.register("hasIndiaScopeXbr", NodeDef(
        deps=("routerJurisdictionXB",),
        compute=lambda d, ctx: d["routerJurisdictionXB"] not in ("single_us", "us_only"),
    ))

    return r
